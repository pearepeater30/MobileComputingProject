package com.example.myapplication;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import info.sqlite.helper.DBHelper;
import info.sqlite.model.List_Item;
import info.sqlite.model.ShoppingList;
import recyclerView.ItemListAdapter;

import java.util.ArrayList;
import java.util.List;

public class SecondaryList extends AppCompatActivity {

    private DBHelper dbHelper;
    private RecyclerView recyclerView;
    private ItemListAdapter mAdapter;
    private List<List_Item> listOfItems;
    private int list_ID = 0;
    TextView listID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondary_list);
        Intent intent = getIntent();
        String newTitle = intent.getStringExtra("List_Name");
        list_ID = intent.getIntExtra("List_ID",0);
        setTitle(newTitle);

        listOfItems = new ArrayList<List_Item>();
        recyclerView = (RecyclerView) findViewById(R.id.itemListView);
        mAdapter = new ItemListAdapter(this, listOfItems);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        recyclerView.setAdapter(mAdapter);

        listID = findViewById(R.id.listIDText);
        listID.setText("List ID:" + Integer.toString(list_ID));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
                deleteData((List_Item) viewHolder.itemView.getTag(), list_ID);
                listOfItems.remove(viewHolder.itemView.getTag());
                mAdapter.notifyDataSetChanged();
            }
        }).attachToRecyclerView(recyclerView);

        FloatingActionButton fab = findViewById(R.id.floatingActionButton2);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SecondaryList.this, AddItemToList.class);
                intent.putExtra("List_ID", list_ID);
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });
        prepareData();
    }

    @Override
    protected void onResume(){
        super.onResume();
        listOfItems.clear();
        mAdapter.notifyDataSetChanged();
        prepareData();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void finish(){
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    private void prepareData(){
        dbHelper = new DBHelper(this);
        List<List_Item> shoppingList = dbHelper.getAllItemsfromList(list_ID);
        listOfItems.addAll(shoppingList);
    }

    private void deleteData(List_Item item, int list_ID){
        String deletedItem = item.getItemName();
        dbHelper = new DBHelper(this);
        dbHelper.deleteItem(item, list_ID);
        Toast.makeText(getApplicationContext(), deletedItem + " was successfully deleted", Toast.LENGTH_LONG).show();
    }
}
