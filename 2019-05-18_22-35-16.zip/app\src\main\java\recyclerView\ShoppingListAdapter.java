package recyclerView;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.example.myapplication.R;
import com.example.myapplication.SecondaryList;
import info.sqlite.helper.DBHelper;
import info.sqlite.model.ShoppingList;

import java.util.List;

public class ShoppingListAdapter extends RecyclerView.Adapter<ShoppingListAdapter.ViewHolder> {
    private final List<ShoppingList> shoppingListList;
    private LayoutInflater mInflater;
    DBHelper dbHelper;

    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public final TextView shoppingListView;
        public final ShoppingListAdapter mAdapter;

        public ViewHolder(View itemView, ShoppingListAdapter adapter){
            super(itemView);
            shoppingListView = itemView.findViewById(R.id.textViewShoppingListView);
            this.mAdapter = adapter;
            itemView.setOnClickListener(this);
        }

        /**
         * passing data to the Secondary List activity
         * @param v
         */
        @Override
        public void onClick(View v) {
            int mPosition = getLayoutPosition();
            int listID = shoppingListList.get(mPosition).getListID();
            String listName = shoppingListList.get(mPosition).getListName();
            Context context = v.getContext();
            Intent intent = new Intent(context, SecondaryList.class);
            intent.putExtra("List_ID", listID);
            intent.putExtra("List_Name",listName);
            context.startActivity(intent);
        }
    }

    public ShoppingListAdapter(Context context, List<ShoppingList> list) {
        mInflater = LayoutInflater.from(context);
        this.shoppingListList = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View mItemView = mInflater.inflate(R.layout.recyclerview_shoppipnglist_row, viewGroup, false);
        return new ViewHolder(mItemView, this);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        ShoppingList mCurrent = shoppingListList.get(position);
        viewHolder.shoppingListView.setText(mCurrent.getListName());
        ShoppingList shoppingList = shoppingListList.get(position);
        viewHolder.itemView.setTag(shoppingList);
    }

    @Override
    public int getItemCount() {
        return shoppingListList.size();
    }

    public List<ShoppingList> getShoppingList(){
        return shoppingListList;
    }
}
